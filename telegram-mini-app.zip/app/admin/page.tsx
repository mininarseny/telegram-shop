"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { motion } from "framer-motion"
import { useRouter } from "next/navigation"
import { ShoppingBag, Tag, LogOut, Plus, Trash, Edit, Save, X, ArrowLeft, Eye, EyeOff } from "lucide-react"

// Admin authentication state
interface AdminAuth {
  isAuthenticated: boolean
  username: string
  password: string
}

// Product type definition
interface Product {
  id: number
  name: string
  price: number
  originalPrice?: number
  image: string
  description: string
  category: string
  isNew?: boolean
  isAvailable: boolean
}

// Sample products data
const initialProducts: Product[] = [
  {
    id: 1,
    name: "Vintage Denim Jacket",
    price: 89.99,
    originalPrice: 129.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Authentic vintage denim jacket from the 90s. One-of-a-kind piece with unique distressing and fading.",
    category: "Outerwear",
    isNew: true,
    isAvailable: true,
  },
  {
    id: 2,
    name: "Hand-painted T-Shirt",
    price: 59.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Custom hand-painted t-shirt with original artwork. Each piece is unique and signed by the artist.",
    category: "T-Shirts",
    isNew: true,
    isAvailable: true,
  },
  {
    id: 3,
    name: "Reworked Cargo Pants",
    price: 79.99,
    image: "/placeholder.svg?height=300&width=300",
    description:
      "Vintage cargo pants reworked with custom pockets and details. One size fits most with adjustable waist.",
    category: "Pants",
    isAvailable: true,
  },
  {
    id: 4,
    name: "Embroidered Hoodie",
    price: 69.99,
    originalPrice: 89.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Premium cotton hoodie with hand-embroidered details. Each stitch pattern is unique.",
    category: "Outerwear",
    isAvailable: true,
  },
  {
    id: 5,
    name: "Upcycled Denim Bag",
    price: 45.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Handcrafted bag made from upcycled denim. Features unique pocket details and sturdy construction.",
    category: "Accessories",
    isNew: true,
    isAvailable: true,
  },
  {
    id: 6,
    name: "Vintage Band Tee",
    price: 39.99,
    originalPrice: 54.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Authentic vintage band t-shirt from the 80s. Rare find in excellent condition.",
    category: "T-Shirts",
    isAvailable: true,
  },
  {
    id: 7,
    name: "Custom Leather Jacket",
    price: 189.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Handcrafted leather jacket with custom hardware and detailing. One-of-a-kind statement piece.",
    category: "Outerwear",
    isNew: true,
    isAvailable: true,
  },
  {
    id: 8,
    name: "Patchwork Denim Skirt",
    price: 69.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Unique patchwork denim skirt made from vintage jeans. Each panel has its own character and history.",
    category: "Bottoms",
    isAvailable: true,
  },
]

// Get unique categories from products
const getUniqueCategories = (products: Product[]) => {
  return Array.from(new Set(products.map((product) => product.category)))
}

export default function AdminPanel() {
  const [auth, setAuth] = useState<AdminAuth>({
    isAuthenticated: false,
    username: "",
    password: "",
  })

  const [products, setProducts] = useState<Product[]>(initialProducts)
  const [categories, setCategories] = useState<string[]>(getUniqueCategories(initialProducts))
  const [newCategory, setNewCategory] = useState<string>("")
  const [editingCategory, setEditingCategory] = useState<{ original: string; new: string } | null>(null)

  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: "",
    price: 0,
    originalPrice: undefined,
    image: "/placeholder.svg?height=300&width=300",
    description: "",
    category: categories[0] || "",
    isNew: false,
    isAvailable: true,
  })

  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [isAddingProduct, setIsAddingProduct] = useState(false)
  const [isAddingCategory, setIsAddingCategory] = useState(false)
  const [showPassword, setShowPassword] = useState(false)

  const router = useRouter()

  // Login handler
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    // Simple mock authentication - in a real app, this would be a server request
    if (auth.username === "admin" && auth.password === "password") {
      setAuth({ ...auth, isAuthenticated: true })
    } else {
      alert("Invalid credentials. Try username: admin, password: password")
    }
  }

  // Logout handler
  const handleLogout = () => {
    setAuth({
      isAuthenticated: false,
      username: "",
      password: "",
    })
  }

  // Go back to store
  const goToStore = () => {
    router.push("/")
  }

  // Add new category
  const addCategory = () => {
    if (newCategory.trim() === "") return
    if (categories.includes(newCategory.trim())) {
      alert("This category already exists")
      return
    }

    setCategories([...categories, newCategory.trim()])
    setNewCategory("")
    setIsAddingCategory(false)
  }

  // Edit category
  const updateCategory = () => {
    if (!editingCategory) return
    if (editingCategory.new.trim() === "") return
    if (categories.includes(editingCategory.new.trim()) && editingCategory.original !== editingCategory.new.trim()) {
      alert("This category already exists")
      return
    }

    const updatedCategories = categories.map((cat) =>
      cat === editingCategory.original ? editingCategory.new.trim() : cat,
    )

    // Update product categories as well
    const updatedProducts = products.map((product) => ({
      ...product,
      category: product.category === editingCategory.original ? editingCategory.new.trim() : product.category,
    }))

    setCategories(updatedCategories)
    setProducts(updatedProducts)
    setEditingCategory(null)
  }

  // Delete category
  const deleteCategory = (category: string) => {
    if (window.confirm(`Are you sure you want to delete the category "${category}"?`)) {
      const updatedCategories = categories.filter((cat) => cat !== category)

      // Set products in this category to a default category or remove them
      const updatedProducts = products.map((product) => {
        if (product.category === category) {
          return {
            ...product,
            category: updatedCategories[0] || "Uncategorized",
          }
        }
        return product
      })

      setCategories(updatedCategories)
      setProducts(updatedProducts)
    }
  }

  // Add new product
  const addProduct = () => {
    if (!newProduct.name || !newProduct.price || !newProduct.description || !newProduct.category) {
      alert("Please fill in all required fields")
      return
    }

    const newId = Math.max(...products.map((p) => p.id), 0) + 1

    const productToAdd: Product = {
      id: newId,
      name: newProduct.name,
      price: Number(newProduct.price),
      originalPrice: newProduct.originalPrice ? Number(newProduct.originalPrice) : undefined,
      image: newProduct.image || "/placeholder.svg?height=300&width=300",
      description: newProduct.description,
      category: newProduct.category,
      isNew: newProduct.isNew || false,
      isAvailable: newProduct.isAvailable !== undefined ? newProduct.isAvailable : true,
    }

    setProducts([...products, productToAdd])
    setNewProduct({
      name: "",
      price: 0,
      originalPrice: undefined,
      image: "/placeholder.svg?height=300&width=300",
      description: "",
      category: categories[0] || "",
      isNew: false,
      isAvailable: true,
    })
    setIsAddingProduct(false)
  }

  // Update product
  const updateProduct = () => {
    if (!editingProduct) return

    if (!editingProduct.name || !editingProduct.price || !editingProduct.description || !editingProduct.category) {
      alert("Please fill in all required fields")
      return
    }

    const updatedProducts = products.map((product) => (product.id === editingProduct.id ? editingProduct : product))

    setProducts(updatedProducts)
    setEditingProduct(null)
  }

  // Delete product
  const deleteProduct = (id: number) => {
    if (window.confirm("Are you sure you want to delete this product?")) {
      const updatedProducts = products.filter((product) => product.id !== id)
      setProducts(updatedProducts)
    }
  }

  // Toggle product availability
  const toggleProductAvailability = (id: number) => {
    const updatedProducts = products.map((product) =>
      product.id === id ? { ...product, isAvailable: !product.isAvailable } : product,
    )
    setProducts(updatedProducts)
  }

  if (!auth.isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-50 dark:bg-zinc-900 p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <Card className="border-zinc-200 dark:border-zinc-800">
            <CardHeader>
              <CardTitle className="text-center">Admin Login</CardTitle>
              <CardDescription className="text-center">
                Enter your credentials to access the admin panel
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    type="text"
                    value={auth.username}
                    onChange={(e) => setAuth({ ...auth, username: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={auth.password}
                      onChange={(e) => setAuth({ ...auth, password: e.target.value })}
                      required
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>
                <Button
                  type="submit"
                  className="w-full bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
                >
                  Login
                </Button>
              </form>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={goToStore}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Store
              </Button>
            </CardFooter>
          </Card>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-zinc-50 dark:bg-zinc-900">
      <header className="sticky top-0 z-10 bg-white dark:bg-zinc-950 border-b border-zinc-200 dark:border-zinc-800 p-4">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold">Admin Panel</h1>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={goToStore}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Store
            </Button>
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto p-4">
        <Tabs defaultValue="products" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="products" className="flex items-center">
              <ShoppingBag className="mr-2 h-4 w-4" />
              Products
            </TabsTrigger>
            <TabsTrigger value="categories" className="flex items-center">
              <Tag className="mr-2 h-4 w-4" />
              Categories
            </TabsTrigger>
          </TabsList>

          <TabsContent value="products" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">Products</h2>
              {!isAddingProduct && (
                <Button
                  onClick={() => setIsAddingProduct(true)}
                  className="bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Product
                </Button>
              )}
            </div>

            {isAddingProduct && (
              <Card className="border-zinc-200 dark:border-zinc-800">
                <CardHeader>
                  <CardTitle>Add New Product</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Name *</Label>
                        <Input
                          id="name"
                          value={newProduct.name}
                          onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="category">Category *</Label>
                        <select
                          id="category"
                          className="w-full p-2 rounded-md border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-950"
                          value={newProduct.category}
                          onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                          required
                        >
                          {categories.map((category) => (
                            <option key={category} value={category}>
                              {category}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="price">Price *</Label>
                        <Input
                          id="price"
                          type="number"
                          step="0.01"
                          value={newProduct.price}
                          onChange={(e) => setNewProduct({ ...newProduct, price: Number.parseFloat(e.target.value) })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="originalPrice">Original Price (optional)</Label>
                        <Input
                          id="originalPrice"
                          type="number"
                          step="0.01"
                          value={newProduct.originalPrice || ""}
                          onChange={(e) =>
                            setNewProduct({
                              ...newProduct,
                              originalPrice: e.target.value ? Number.parseFloat(e.target.value) : undefined,
                            })
                          }
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="image">Image URL</Label>
                      <Input
                        id="image"
                        value={newProduct.image}
                        onChange={(e) => setNewProduct({ ...newProduct, image: e.target.value })}
                        placeholder="/placeholder.svg?height=300&width=300"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="description">Description *</Label>
                      <textarea
                        id="description"
                        className="w-full p-2 rounded-md border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-950 min-h-[100px]"
                        value={newProduct.description}
                        onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                        required
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="isNew"
                        checked={newProduct.isNew || false}
                        onChange={(e) => setNewProduct({ ...newProduct, isNew: e.target.checked })}
                        className="rounded border-zinc-300 dark:border-zinc-700"
                      />
                      <Label htmlFor="isNew">Mark as New</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="isAvailable"
                        checked={newProduct.isAvailable !== undefined ? newProduct.isAvailable : true}
                        onChange={(e) => setNewProduct({ ...newProduct, isAvailable: e.target.checked })}
                        className="rounded border-zinc-300 dark:border-zinc-700"
                      />
                      <Label htmlFor="isAvailable">Available for Purchase</Label>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsAddingProduct(false)}>
                    Cancel
                  </Button>
                  <Button
                    onClick={addProduct}
                    className="bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
                  >
                    Add Product
                  </Button>
                </CardFooter>
              </Card>
            )}

            {editingProduct && (
              <Card className="border-zinc-200 dark:border-zinc-800">
                <CardHeader>
                  <CardTitle>Edit Product</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="edit-name">Name *</Label>
                        <Input
                          id="edit-name"
                          value={editingProduct.name}
                          onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="edit-category">Category *</Label>
                        <select
                          id="edit-category"
                          className="w-full p-2 rounded-md border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-950"
                          value={editingProduct.category}
                          onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                          required
                        >
                          {categories.map((category) => (
                            <option key={category} value={category}>
                              {category}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="edit-price">Price *</Label>
                        <Input
                          id="edit-price"
                          type="number"
                          step="0.01"
                          value={editingProduct.price}
                          onChange={(e) =>
                            setEditingProduct({ ...editingProduct, price: Number.parseFloat(e.target.value) })
                          }
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="edit-originalPrice">Original Price (optional)</Label>
                        <Input
                          id="edit-originalPrice"
                          type="number"
                          step="0.01"
                          value={editingProduct.originalPrice || ""}
                          onChange={(e) =>
                            setEditingProduct({
                              ...editingProduct,
                              originalPrice: e.target.value ? Number.parseFloat(e.target.value) : undefined,
                            })
                          }
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-image">Image URL</Label>
                      <Input
                        id="edit-image"
                        value={editingProduct.image}
                        onChange={(e) => setEditingProduct({ ...editingProduct, image: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-description">Description *</Label>
                      <textarea
                        id="edit-description"
                        className="w-full p-2 rounded-md border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-950 min-h-[100px]"
                        value={editingProduct.description}
                        onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                        required
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="edit-isNew"
                        checked={editingProduct.isNew || false}
                        onChange={(e) => setEditingProduct({ ...editingProduct, isNew: e.target.checked })}
                        className="rounded border-zinc-300 dark:border-zinc-700"
                      />
                      <Label htmlFor="edit-isNew">Mark as New</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="edit-isAvailable"
                        checked={editingProduct.isAvailable}
                        onChange={(e) => setEditingProduct({ ...editingProduct, isAvailable: e.target.checked })}
                        className="rounded border-zinc-300 dark:border-zinc-700"
                      />
                      <Label htmlFor="edit-isAvailable">Available for Purchase</Label>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setEditingProduct(null)}>
                    Cancel
                  </Button>
                  <Button
                    onClick={updateProduct}
                    className="bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
                  >
                    Save Changes
                  </Button>
                </CardFooter>
              </Card>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {products.map((product) => (
                <Card
                  key={product.id}
                  className={`border-zinc-200 dark:border-zinc-800 ${!product.isAvailable ? "opacity-70" : ""}`}
                >
                  <div className="flex h-full">
                    <div className="relative w-24 h-24 shrink-0 m-4 rounded-md overflow-hidden">
                      <img
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        className={`object-cover w-full h-full ${!product.isAvailable ? "grayscale" : ""}`}
                      />
                    </div>
                    <div className="flex-1 p-4 flex flex-col">
                      <div className="flex justify-between">
                        <h3 className="font-medium truncate">{product.name}</h3>
                        <div className="flex items-center gap-1">
                          {product.isNew && (
                            <span className="px-1.5 py-0.5 text-xs bg-zinc-900 text-white dark:bg-white dark:text-zinc-900 rounded">
                              NEW
                            </span>
                          )}
                          <span
                            className={`px-1.5 py-0.5 text-xs rounded ${
                              product.isAvailable
                                ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100"
                                : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100"
                            }`}
                          >
                            {product.isAvailable ? "Available" : "Sold Out"}
                          </span>
                        </div>
                      </div>
                      <div className="text-sm text-zinc-500 dark:text-zinc-400 mb-1">{product.category}</div>
                      <div className="flex items-center gap-1 mb-1">
                        <span className="font-semibold">${product.price}</span>
                        {product.originalPrice && (
                          <span className="text-xs text-zinc-500 dark:text-zinc-400 line-through">
                            ${product.originalPrice}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-zinc-600 dark:text-zinc-300 line-clamp-2 mb-2">
                        {product.description}
                      </p>
                      <div className="mt-auto flex justify-end gap-2">
                        <Button variant="outline" size="sm" onClick={() => toggleProductAvailability(product.id)}>
                          {product.isAvailable ? "Mark Sold" : "Mark Available"}
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => setEditingProduct(product)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
                          onClick={() => deleteProduct(product.id)}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="categories" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">Categories</h2>
              {!isAddingCategory && (
                <Button
                  onClick={() => setIsAddingCategory(true)}
                  className="bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Category
                </Button>
              )}
            </div>

            {isAddingCategory && (
              <Card className="border-zinc-200 dark:border-zinc-800">
                <CardHeader>
                  <CardTitle>Add New Category</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="category-name">Category Name</Label>
                      <Input
                        id="category-name"
                        value={newCategory}
                        onChange={(e) => setNewCategory(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsAddingCategory(false)}>
                    Cancel
                  </Button>
                  <Button
                    onClick={addCategory}
                    className="bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
                  >
                    Add Category
                  </Button>
                </CardFooter>
              </Card>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {categories.map((category) => (
                <Card key={category} className="border-zinc-200 dark:border-zinc-800">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      {editingCategory && editingCategory.original === category ? (
                        <Input
                          value={editingCategory.new}
                          onChange={(e) => setEditingCategory({ ...editingCategory, new: e.target.value })}
                          className="flex-1 mr-2"
                        />
                      ) : (
                        <h3 className="font-medium">{category}</h3>
                      )}
                      <div className="flex items-center gap-2">
                        {editingCategory && editingCategory.original === category ? (
                          <>
                            <Button variant="ghost" size="sm" onClick={() => setEditingCategory(null)}>
                              <X className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={updateCategory}>
                              <Save className="h-4 w-4" />
                            </Button>
                          </>
                        ) : (
                          <>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setEditingCategory({ original: category, new: category })}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-red-500 hover:text-red-600"
                              onClick={() => deleteCategory(category)}
                            >
                              <Trash className="h-4 w-4" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                    <div className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
                      {products.filter((p) => p.category === category).length} products
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
